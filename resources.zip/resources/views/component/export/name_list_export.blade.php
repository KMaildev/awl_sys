<tr>
    <td>
        {{ $loop->iteration }}
    </td>

    <td>
        {{ $name_list->no ?? '' }}
    </td>

    <td>
        {{ $name_list->gender ?? '' }}
    </td>

    <td>
        {{ $name_list->name ?? '' }}
    </td>

    <td>
        {{ $name_list->date_of_birth ?? '' }}
    </td>

    <td>
        {{ $name_list->age ?? '' }}
    </td>

    <td>
        {{ $name_list->father_name ?? '' }}
    </td>

    <td>
        {{ $name_list->qualification ?? '' }}
    </td>

    <td>
        {{ $name_list->nrc ?? '' }}
    </td>

    <td>
        {{ $name_list->physical_and_blindness_test ?? '' }}
    </td>

    <td>
        {{ $name_list->medical_fail ?? '' }}
    </td>

    <td>
        {{ $name_list->covid_vaccine_first_dose ?? '' }}
    </td>

    <td>
        {{ $name_list->covid_vaccine_second_dose ?? '' }}
    </td>

    <td>
        {{ $name_list->region ?? '' }}
    </td>

    <td>
        {{ $name_list->native_town ?? '' }}
    </td>

    <td>
        {{ $name_list->come_from_to_interview ?? '' }}
    </td>


    <td>
        {{ $name_list->passport_issue_date ?? '' }}
    </td>

    <td>
        {{ $name_list->expiry_date ?? '' }}
    </td>


    <td>
        {{ $name_list->slip_date ?? '' }}
    </td>


    <td>
        {{ $name_list->passport_number ?? '' }}
    </td>

    <td>
        {{ $name_list->departure_date ?? '' }}
    </td>


    <td>
        {{ $name_list->phone_number ?? '' }}
    </td>


    <td>
        {{ $name_list->remark ?? '' }}
    </td>

    <td>
        {{ $name_list->fail_cancel ?? '' }}
    </td>

    <td>
        {{ $name_list->contract_no ?? '' }}
    </td>

    <td>
        {{ $name_list->note ?? '' }}
    </td>
</tr>
