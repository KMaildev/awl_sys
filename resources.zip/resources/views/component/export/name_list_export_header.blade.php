<thead>
    <tr class="tbbg">
        <th class="text-center cw" style="width: 5vh">
            #
        </th>

        <th class="text-center cw" style="width: 5vh">
            No
        </th>

        <th class="text-center cw" style="width: 5vh">
            Gender
        </th>

        <th class="text-center cw" style="width: 5vh">
            Name
        </th>

        <th class="text-center cw" style="width: 5vh">
            Date of birth
        </th>

        <th class="text-center cw" style="width: 5vh">
            Age
        </th>

        <th class="text-center cw" style="width: 5vh">
            Father's name
        </th>


        <th class="text-center cw" style="width: 5vh">
            Qualification
        </th>

        <th class="text-center cw" style="width: 5vh">
            NRC
        </th>

        <th class="text-center cw" style="width: 5vh">
            Physical And Blindness Test
        </th>

        <th class="text-center cw" style="width: 5vh">
            Medical
        </th>

        <th class="text-center cw" style="width: 5vh">
            Covid Vaccine First Dose
        </th>


        <th class="text-center cw" style="width: 5vh">
            Covid Vaccine Second Dose
        </th>

        <th class="text-center cw" style="width: 5vh">
            Region
        </th>

        <th class="text-center cw" style="width: 5vh">
            Native Town
        </th>
        

        <th class="text-center cw" style="width: 5vh">
            Come From To Interview
        </th>

        <th class="text-center cw" style="width: 5vh">
            Passport Issue Date
        </th>

        <th class="text-center cw" style="width: 5vh">
            Passport Expire Date
        </th>

        <th class="text-center cw" style="width: 5vh">
            Passport Slip Date
        </th>

        <th class="text-center cw" style="width: 5vh">
            Passport Number
        </th>

        <th class="text-center cw" style="width: 5vh">
            Departure Date
        </th>

        <th class="text-center cw" style="width: 5vh">
            Phone Number
        </th>

        <th class="text-center cw" style="width: 5vh">
            Remark
        </th>

        <th class="text-center cw" style="width: 5vh">
            Fail Or Cancel
        </th>

        <th class="text-center cw" style="width: 5vh">
            Contract No
        </th>

        <th class="text-center cw" style="width: 5vh">
            Note
        </th>

    </tr>
</thead>
