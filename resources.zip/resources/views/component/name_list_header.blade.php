<thead>
    <tr class="tbbg">
        <th style="color: white; width: 1%;">
            #
        </th>

        <th style="color: white; width: 1%;">
            No
        </th>

        <th class="text-center cw">
            Gender
        </th>

        <th class="text-center cw">
            Name
        </th>

        <th class="text-center cw">
            Date of birth
        </th>

        <th class="text-center cw">
            Age
        </th>

        <th class="text-center cw">
            Father's name
        </th>

        <th class="text-center cw">
            Qualification
        </th>

        <th class="text-center cw">
            NRC
        </th>

        <th class="text-center cw">
            Physical And Blindness Test
        </th>

        <th class="text-center cw">
            Medical
        </th>

        <th class="text-center cw">
            Covid Vaccine First Dose
        </th>


        <th class="text-center cw">
            Covid Vaccine Second Dose
        </th>

        <th class="text-center cw">
            Region
        </th>

        <th class="text-center cw">
            Native Town
        </th>


        <th class="text-center cw">
            Come From To Interview
        </th>

        <th class="text-center cw">
            Passport Issue Date
        </th>

        <th class="text-center cw">
            Passport Expire Date
        </th>

        <th class="text-center cw">
            Passport Slip Date
        </th>

        <th class="text-center cw">
            Passport Number
        </th>

        <th class="text-center cw">
            Departure Date
        </th>

        <th class="text-center cw">
            Phone Number
        </th>

        <th class="text-center cw">
            Remark
        </th>

        <th class="text-center cw">
            Fail Or Cancel
        </th>

        <th class="text-center cw">
            Contract No
        </th>

        <th class="text-center cw">
            Note
        </th>

        <th class="text-center cw">
            Action
        </th>

    </tr>
</thead>
