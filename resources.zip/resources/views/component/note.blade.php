<input type="text" value="{{ $name_list->note ?? '' }}" data-id="{{ $name_list->id }}" class="updateNote"
    style="width: 140px;">
