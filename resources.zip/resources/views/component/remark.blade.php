<input type="text" value="{{ $name_list->remark ?? '' }}" data-id="{{ $name_list->id }}" class="updateRemark"
    style="width: 140px;">
