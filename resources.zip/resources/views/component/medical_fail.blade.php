<input type="text" value="{{ $name_list->medical_fail ?? '' }}" data-id="{{ $name_list->id }}" class="updateMedicalFail"
    style="width: 100%;">
